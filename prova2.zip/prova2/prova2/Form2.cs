﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prova2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        int infantil;
        string safari;
        string ladybug;
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Items = infantil;)
            {
                listBox1.Items = safari;ladybug;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamWriter arquivo;
            arquivo = new StreamWriter("festa.txt");
            arquivo.Writeline(label2.Text; monthCalendar1.DateChanged;comboBox1.Items;);
            arquivo.close();
            MessageBox.Show("Arquivo gravado com sucesso!");
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text.Remove();
            label1.Text.Remove();
            comboBox1.Items.Remove();
            checkBox1.Checked.Remove();
            checkBox2.Checked.Remove();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
